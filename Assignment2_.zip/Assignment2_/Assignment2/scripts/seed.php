<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require __DIR__ . '/../app/functions.php';
if ((int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn() !== 0 || (int)db()->query('SELECT COUNT(*) FROM listings')->fetchColumn() !== 0) {
    fwrite(STDERR,"Seed refused: users and listings must both be empty.\n"); exit(1);
}
$adminPass=getenv('SEED_ADMIN_PASSWORD'); $hostPass=getenv('SEED_HOST_PASSWORD');
foreach ([$adminPass,$hostPass] as $password) {
    if (!$password || strlen($password)<12 || strlen($password)>72 || str_contains($password,"\0")) { fwrite(STDERR,"Set SEED_ADMIN_PASSWORD and SEED_HOST_PASSWORD to 12–72 byte passwords.\n"); exit(1); }
}
if ($adminPass===$hostPass) { fwrite(STDERR,"Use different passwords for the two accounts.\n"); exit(1); }
db()->beginTransaction();
try {
    $s=db()->prepare('INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,?)');
    $s->execute(['Demo Admin','admin@wanderlust.test',password_hash($adminPass,PASSWORD_DEFAULT),'admin']);
    $s->execute(['Demo Host','host@wanderlust.test',password_hash($hostPass,PASSWORD_DEFAULT),'member']);
    $hostId=db()->lastInsertId();
    $s=db()->prepare('INSERT INTO listings (user_id,title,description,image_url,price,location,country) VALUES (?,?,?,?,?,?,?)');
    foreach (json_decode(file_get_contents(__DIR__.'/../database/listings.json'),true,512,JSON_THROW_ON_ERROR) as $l) {
        $s->execute([$hostId,$l['title'],$l['description'],$l['image_url'],$l['price'],$l['location'],$l['country']]);
    }
    db()->commit(); echo "Created two demo users and ten listings. Passwords were hashed, not stored in source.\n";
} catch (Throwable $e) { db()->rollBack(); throw $e; }
