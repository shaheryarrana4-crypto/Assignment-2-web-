<?php
require __DIR__ . '/../app/bootstrap.php';
if (current_user()) go('my-listings.php');
$errors=[]; $email='';
if (post()) {
    csrf_check(); $email=strtolower(input('email'));
    $password=isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';
    // Classroom-only session throttle; production needs account/IP rate limits.
    $attempts=$_SESSION['login_attempts'] ?? ['count'=>0,'start'=>time()];
    if (time()-$attempts['start']>=300) $attempts=['count'=>0,'start'=>time()];
    if ($attempts['count']>=5) { http_response_code(429); $errors[]='Too many attempts in this session. Wait five minutes.'; }
    else {
        $s=db()->prepare('SELECT * FROM users WHERE email=?'); $s->execute([$email]); $user=$s->fetch();
        $dummy='$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
        $ok=password_verify($password, $user ? $user['password_hash'] : $dummy);
        if (!$user || !$ok || strlen($password)>72 || strlen($password)<12) {
            $attempts['count']++; $_SESSION['login_attempts']=$attempts;
            $errors[]='Invalid email or password.';
        } else {
            if (password_needs_rehash($user['password_hash'],PASSWORD_DEFAULT)) {
                $s=db()->prepare('UPDATE users SET password_hash=? WHERE id=?');
                $s->execute([password_hash($password,PASSWORD_DEFAULT),$user['id']]);
            }
            session_regenerate_id(true); $_SESSION=[];
            $_SESSION['user_id']=(int)$user['id']; csrf_token();
            flash('Welcome back, '.$user['name'].'!'); go('my-listings.php');
        }
    }
}
$pageTitle='Log in'; require __DIR__ . '/../app/header.php';
?>
<section class="auth-panel"><h1 class="h3 mb-3">Welcome back</h1><?php errors_box($errors); ?>
<form method="post"><?php csrf_field(); ?>
<div class="mb-3"><label for="email" class="form-label">Email address</label><input type="email" class="form-control" id="email" name="email" value="<?= e($email) ?>" maxlength="254" autocomplete="username" required></div>
<div class="mb-3"><label for="password" class="form-label">Password</label><input type="password" class="form-control" id="password" name="password" autocomplete="current-password" required></div>
<button class="btn btn-brand w-100">Log in</button></form><p class="mt-3">New to Wander Lust? <a href="register.php">Create an account</a></p></section>
<?php require __DIR__ . '/../app/footer.php'; ?>
