<?php
require __DIR__ . '/../app/bootstrap.php';
if (current_user()) go('my-listings.php');
$errors = []; $name = ''; $email = '';
if (post()) {
    csrf_check(); $name = input('name'); $email = strtolower(input('email'));
    $password = isset($_POST['password']) && is_string($_POST['password']) ? $_POST['password'] : '';
    $confirm = isset($_POST['confirm']) && is_string($_POST['confirm']) ? $_POST['confirm'] : '';
    if (strlen($name)<2 || strlen($name)>100) $errors[]='Name must be 2–100 bytes long.';
    if (strlen($email)>254 || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[]='Enter a valid email address (maximum 254 bytes).';
    if (strlen($password)<12 || strlen($password)>72) $errors[]='Password must be 12–72 bytes long.';
    if (str_contains($password, "\0")) $errors[]='Password contains an unsupported character.';
    if ($password !== $confirm) $errors[]='Passwords do not match.';
    if (!$errors) {
        try {
            $s = db()->prepare("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'member')");
            $s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
            flash('Registration successful. You can now log in.'); go('login.php');
        } catch (PDOException $e) {
            if (($e->errorInfo[1] ?? 0) === 1062) $errors[]='That email is already registered.'; else throw $e;
        }
    }
}
$pageTitle='Register'; require __DIR__ . '/../app/header.php';
?>
<section class="auth-panel"><h1 class="h3 mb-3">Create your account</h1><?php errors_box($errors); ?>
<form method="post"><?php csrf_field(); ?>
<div class="mb-3"><label class="form-label" for="name">Full name</label><input class="form-control" id="name" name="name" autocomplete="name" maxlength="100" required value="<?= e($name) ?>"></div>
<div class="mb-3"><label class="form-label" for="email">Email address</label><input class="form-control" id="email" name="email" type="email" autocomplete="email" maxlength="254" required value="<?= e($email) ?>"></div>
<div class="mb-3"><label class="form-label" for="password">Password</label><input class="form-control" id="password" name="password" type="password" minlength="12" maxlength="72" autocomplete="new-password" required aria-describedby="password-help"><div class="form-text" id="password-help">12–72 bytes. Use a long, unique passphrase.</div></div>
<div class="mb-3"><label class="form-label" for="confirm">Confirm password</label><input class="form-control" id="confirm" name="confirm" type="password" autocomplete="new-password" required></div>
<button class="btn btn-brand w-100">Register</button></form><p class="mt-3">Already registered? <a href="login.php">Log in</a></p></section>
<?php require __DIR__ . '/../app/footer.php'; ?>
