<?php if (!$listings): ?><p class="alert alert-light border">No listings found.</p><?php endif; ?>
<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
<?php foreach ($listings as $listing): ?><article class="col"><a class="listing-link" href="listing.php?id=<?= (int)$listing['id'] ?>"><div class="card listing-card">
<img src="<?= e($listing['image_url']) ?>" class="card-img-top" alt="<?= e($listing['title']) ?>" loading="lazy" referrerpolicy="no-referrer">
<div class="card-body px-0"><h2 class="h6 fw-bold"><?= e($listing['title']) ?></h2><p class="mb-1 muted"><?= e($listing['location']) ?>, <?= e($listing['country']) ?></p><p class="mb-0"><span class="price">$<?= number_format((float)$listing['price'],2) ?></span> / night</p></div></div></a></article><?php endforeach; ?></div>
