<?php
require __DIR__ . '/../app/bootstrap.php';
$q = substr(query_text('q'),0,120);
$sql = 'SELECT * FROM listings'; $args = [];
if ($q !== '') { $sql .= ' WHERE title LIKE ? OR location LIKE ? OR country LIKE ?'; $args = array_fill(0,3,'%'.$q.'%'); }
$sql .= ' ORDER BY id DESC';
$s = db()->prepare($sql); $s->execute($args); $listings = $s->fetchAll();
$pageTitle = 'All Listings'; require __DIR__ . '/../app/header.php';
?>
<section class="hero"><p class="text-uppercase small muted">Find your next escape</p><h1 class="fw-bold">All Listings</h1><p class="muted">Distinctive stays. Memorable places. Your next adventure starts here.</p></section>
<form class="row g-2 mb-4" method="get"><div class="col-sm-9"><label for="q" class="visually-hidden">Search title, city or country</label><input class="form-control" id="q" name="q" value="<?= e($q) ?>" maxlength="120" placeholder="Search title, city or country"></div><div class="col-sm-3"><button class="btn btn-brand w-100">Search listings</button></div></form>
<p class="small muted"><?= count($listings) ?> listing(s)<?= $q !== '' ? ' matching “'.e($q).'”' : '' ?></p>
<?php require __DIR__ . '/../app/cards.php'; require __DIR__ . '/../app/footer.php'; ?>
