<?php
require __DIR__ . '/../app/bootstrap.php'; $u=require_login();
$s=db()->prepare('SELECT * FROM listings WHERE user_id=? ORDER BY id DESC');
$s->execute([$u['id']]); $listings=$s->fetchAll();
$pageTitle='My Listings'; require __DIR__ . '/../app/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4"><h1 class="h3">My Listings</h1><a class="btn btn-brand" href="listing-form.php">Add Listing</a></div>
<p class="muted">Open a listing to edit or delete it.</p>
<?php require __DIR__ . '/../app/cards.php'; require __DIR__ . '/../app/footer.php'; ?>
