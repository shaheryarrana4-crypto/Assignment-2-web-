<?php $navUser = current_user(); ?>
<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'All Listings') ?> | Wander Lust</title>
<link href="assets/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css"></head><body>
<nav class="navbar navbar-expand-md border-bottom sticky-top"><div class="container">
<a class="navbar-brand" href="index.php"><i class="fa-regular fa-compass" aria-hidden="true"></i> Wander Lust</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="navigation"><div class="navbar-nav me-auto">
<a class="nav-link" href="index.php">All Listings</a><a class="nav-link" href="listing-form.php">Add new Listing</a>
<?php if ($navUser): ?><a class="nav-link" href="my-listings.php">My Listings</a><?php endif; ?>
<?php if (($navUser['role'] ?? '') === 'admin'): ?><a class="nav-link" href="admin.php">Admin</a><?php endif; ?></div>
<div class="navbar-nav align-items-md-center gap-2"><?php if ($navUser): ?><span class="small"><?= e($navUser['name']) ?></span>
<form method="post" action="logout.php"><?php csrf_field(); ?><button class="btn btn-outline-dark btn-sm">Log out</button></form>
<?php else: ?><a class="nav-link" href="login.php">Log in</a><a class="btn btn-brand btn-sm" href="register.php">Register</a><?php endif; ?></div></div></div></nav>
<main class="container mt-4 mb-5">
<?php if (isset($_SESSION['flash'])): ?><div class="alert alert-success" role="status"><?= e($_SESSION['flash']) ?></div><?php unset($_SESSION['flash']); endif; ?>
