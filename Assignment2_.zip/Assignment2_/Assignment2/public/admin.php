<?php
require __DIR__ . '/../app/bootstrap.php'; require_admin();
$users=db()->query('SELECT u.id,u.name,u.email,u.role,COUNT(l.id) AS listing_count FROM users u LEFT JOIN listings l ON l.user_id=u.id GROUP BY u.id,u.name,u.email,u.role ORDER BY u.id')->fetchAll();
$listings=db()->query('SELECT * FROM listings ORDER BY id DESC')->fetchAll();
$pageTitle='Admin Dashboard'; require __DIR__ . '/../app/header.php';
?>
<h1 class="h3">Admin Dashboard</h1><p class="muted">Review users and manage any listing. Public registration always creates members, never administrators.</p>
<div class="row my-4"><div class="col"><div class="alert alert-light border"><?= count($users) ?> registered users</div></div><div class="col"><div class="alert alert-light border"><?= count($listings) ?> listings</div></div></div>
<h2 class="h5">User overview</h2><div class="table-responsive mb-4"><table class="table"><thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Role</th><th scope="col">Listings</th></tr></thead><tbody>
<?php foreach ($users as $user): ?><tr><td><?= e($user['name']) ?></td><td><?= e($user['email']) ?></td><td><?= e($user['role']) ?></td><td><?= (int)$user['listing_count'] ?></td></tr><?php endforeach; ?></tbody></table></div><h2 class="h5 mb-3">All listings · open to edit or delete</h2>
<?php require __DIR__ . '/../app/cards.php'; require __DIR__ . '/../app/footer.php'; ?>
