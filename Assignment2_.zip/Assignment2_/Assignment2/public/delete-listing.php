<?php
require __DIR__ . '/../app/bootstrap.php'; $u=require_login();
if (!post()) { header('Allow: POST'); fail(405,'Deletion requires a POST form.'); }
csrf_check();
$id=filter_var(input('id'),FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
if ($id===false) fail(404,'Listing not found.');
$s=db()->prepare('SELECT * FROM listings WHERE id=?'); $s->execute([$id]); $listing=$s->fetch();
if (!$listing) fail(404,'Listing not found.');
if (!can_manage($listing,$u)) fail(403,'You cannot delete another member’s listing.');
$s=db()->prepare('DELETE FROM listings WHERE id=?'); $s->execute([$id]);
flash('Listing deleted.'); go('my-listings.php');
