<?php
require __DIR__ . '/../app/bootstrap.php'; $u=require_login();
$editing=query_text('id')!=='';
$data=['title'=>'','description'=>'','image_url'=>'','price'=>'','location'=>'','country'=>''];
if ($editing) { $listing=listing_by_id(); if (!can_manage($listing,$u)) fail(403,'You cannot edit another member’s listing.'); $data=array_intersect_key($listing,$data); }
$errors=[];
if (post()) {
    csrf_check(); foreach (array_keys($data) as $key) $data[$key]=input($key);
    $errors=validate_listing($data);
    if (!$errors) {
        $values=array_values($data);
        if ($editing) {
            $values[]=$listing['id'];
            $s=db()->prepare('UPDATE listings SET title=?,description=?,image_url=?,price=?,location=?,country=? WHERE id=?');
        } else {
            $values[]=$u['id'];
            $s=db()->prepare('INSERT INTO listings (title,description,image_url,price,location,country,user_id) VALUES (?,?,?,?,?,?,?)');
        }
        $s->execute($values); $id=$editing ? $listing['id'] : db()->lastInsertId();
        flash($editing ? 'Listing updated.' : 'Listing created.'); go('listing.php?id='.$id);
    }
}
$pageTitle=$editing ? 'Edit Listing' : 'Create a New Listing'; require __DIR__ . '/../app/header.php';
?>
<section class="form-panel"><h1 class="h3 mb-4"><?= e($pageTitle) ?></h1><?php errors_box($errors); ?>
<form method="post"><?php csrf_field(); ?>
<?php foreach (['title'=>['Title','text',120], 'image_url'=>['Image URL','url',2048], 'price'=>['Price per night (USD)','number',null], 'location'=>['City / region','text',120], 'country'=>['Country','text',80]] as $key=>$field): ?>
<div class="mb-3"><label class="form-label" for="<?= e($key) ?>"><?= e($field[0]) ?></label><input class="form-control" id="<?= e($key) ?>" name="<?= e($key) ?>" type="<?= e($field[1]) ?>" value="<?= e($data[$key]) ?>" required <?= $key==='price' ? 'min="0.01" max="999999.99" step="0.01"' : 'maxlength="'.(int)$field[2].'"' ?>></div>
<?php endforeach; ?>
<div class="mb-3"><label class="form-label" for="description">Description</label><textarea class="form-control" name="description" id="description" rows="5" minlength="10" maxlength="5000" required><?= e($data['description']) ?></textarea></div>
<button class="btn btn-brand"><?= $editing ? 'Save changes' : 'Add Listing' ?></button> <a class="btn btn-outline-secondary" href="my-listings.php">Cancel</a></form></section>
<?php require __DIR__ . '/../app/footer.php'; ?>
