<?php
require __DIR__ . '/../app/bootstrap.php'; $listing=listing_by_id();
$pageTitle=$listing['title']; require __DIR__ . '/../app/header.php';
?>
<a href="index.php" class="text-dark">&larr; All Listings</a>
<h1 class="h2 mt-4"><?= e($listing['title']) ?></h1><p class="muted"><?= e($listing['location']) ?>, <?= e($listing['country']) ?></p>
<img class="detail-image mb-4" src="<?= e($listing['image_url']) ?>" alt="<?= e($listing['title']) ?>" referrerpolicy="no-referrer">
<div class="row"><div class="col-md-8"><h2 class="h5">About this stay</h2><p><?= nl2br(e($listing['description'])) ?></p><p class="muted">Listed by <?= e($listing['owner_name']) ?></p></div>
<div class="col-md-4"><p><strong class="h4">$<?= number_format((float)$listing['price'],2) ?></strong> / night</p><p class="small muted">Display price in USD. This academic demo does not accept bookings.</p>
<?php if (can_manage($listing,current_user())): ?><a class="btn btn-brand" href="listing-form.php?id=<?= (int)$listing['id'] ?>">Edit listing</a>
<form class="d-inline" method="post" action="delete-listing.php" data-confirm="Permanently delete this listing?"><?php csrf_field(); ?><input type="hidden" name="id" value="<?= (int)$listing['id'] ?>"><button class="btn btn-outline-danger">Delete</button></form><?php endif; ?></div></div>
<?php require __DIR__ . '/../app/footer.php'; ?>
