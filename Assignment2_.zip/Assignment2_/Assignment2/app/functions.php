<?php
declare(strict_types=1);
function db(): PDO {
    static $pdo;
    if ($pdo instanceof PDO) return $pdo;
    $file = __DIR__ . '/../config/config.php';
    $c = is_file($file) ? require $file : [];
    $get = fn(string $key, string $env, string $default): string => (string)(getenv($env) !== false ? getenv($env) : ($c[$key] ?? $default));
    $dsn = 'mysql:host=' . $get('host','DB_HOST','127.0.0.1') . ';port=' . $get('port','DB_PORT','3306') . ';dbname=' . $get('name','DB_NAME','wanderlust') . ';charset=utf8mb4';
    $pdo = new PDO($dsn, $get('user','DB_USER','wanderlust_app'), $get('password','DB_PASS',''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function input(string $key): string { return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : ''; }
function query_text(string $key): string { return isset($_GET[$key]) && is_string($_GET[$key]) ? trim($_GET[$key]) : ''; }
function go(string $path): never { header('Location: ' . $path, true, 303); exit; }
function post(): bool { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): void { echo '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void {
    if (!isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], input('csrf'))) fail(403, 'Invalid or expired form token. Reload the page and try again.');
}
function current_user(): ?array {
    static $loaded = false, $user = null;
    if (!$loaded) {
        $loaded = true;
        if (isset($_SESSION['user_id'])) {
            $s = db()->prepare('SELECT id, name, email, role FROM users WHERE id = ?');
            $s->execute([$_SESSION['user_id']]);
            $user = $s->fetch() ?: null;
            if (!$user) unset($_SESSION['user_id']);
        }
    }
    return $user;
}
function require_login(): array {
    $u = current_user();
    if (!$u) { flash('Please log in to continue.'); go('login.php'); }
    return $u;
}
function require_admin(): array {
    $u = require_login();
    if ($u['role'] !== 'admin') fail(403, 'Administrator access required.');
    return $u;
}
function can_manage(array $listing, ?array $u): bool {
    return $u !== null && ($u['role'] === 'admin' || (int)$listing['user_id'] === (int)$u['id']);
}
function listing_by_id(): array {
    $id = filter_var(query_text('id'), FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
    if ($id === false) fail(404, 'Listing not found.');
    $s = db()->prepare('SELECT l.*, u.name AS owner_name FROM listings l JOIN users u ON u.id=l.user_id WHERE l.id=?');
    $s->execute([$id]);
    return $s->fetch() ?: fail(404, 'Listing not found.');
}
function flash(string $message): void { $_SESSION['flash'] = $message; }
function fail(int $status, string $message): never {
    http_response_code($status);
    $pageTitle = 'Request could not be completed';
    require __DIR__ . '/header.php';
    echo '<div class="alert alert-warning">' . e($message) . '</div><a href="index.php">Back to listings</a>';
    require __DIR__ . '/footer.php'; exit;
}
function errors_box(array $errors): void {
    if (!$errors) return;
    echo '<div class="alert alert-danger" role="alert"><ul class="mb-0">';
    foreach ($errors as $error) echo '<li>' . e($error) . '</li>';
    echo '</ul></div>';
}
function validate_listing(array $data): array {
    $errors = [];
    foreach (['title'=>[3,120], 'description'=>[10,5000], 'location'=>[2,120], 'country'=>[2,80]] as $key=>$bounds) {
        $len = strlen($data[$key] ?? '');
        if ($len < $bounds[0] || $len > $bounds[1]) $errors[] = ucfirst($key) . " must be {$bounds[0]}–{$bounds[1]} bytes long.";
    }
    $url = $data['image_url'] ?? '';
    if (strlen($url)>2048 || !filter_var($url, FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($url, PHP_URL_SCHEME)), ['http','https'], true)) $errors[]='Image must be a valid HTTP or HTTPS URL (maximum 2048 bytes).';
    $price = $data['price'] ?? '';
    if (!preg_match('/^\d{1,6}(\.\d{1,2})?$/D', $price) || (float)$price < .01 || (float)$price > 999999.99) $errors[]='Price must be between 0.01 and 999999.99, with at most two decimal places.';
    return $errors;
}
