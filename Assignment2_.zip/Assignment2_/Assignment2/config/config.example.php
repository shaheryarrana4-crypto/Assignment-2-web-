<?php
// Copy to config.php (ignored by Git); never put credentials in public/.
return [
    'host' => '127.0.0.1', 'port' => '3306',
    'name' => 'wanderlust', 'user' => 'wanderlust_app',
    'password' => 'REPLACE_WITH_YOUR_DATABASE_PASSWORD',
];
