"""Optional report generator. Run: pip install reportlab pillow; python scripts/build_report.py.
Edit the submission fields and contribution table in this script before regenerating.
Screenshots and recorded test evidence are read from docs/ and tests/.
"""
from pathlib import Path
from PIL import Image
import json, re
p=Path(__file__).resolve().parents[1]
seed=json.loads((p/'database/listings.json').read_text())
titles=[r['title'] for r in seed]
prices=[r['price'] for r in seed]
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image as RLImage, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from xml.sax.saxutils import escape
fontdir=Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('DejaVu',str(fontdir/'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('DejaVu-Bold',str(fontdir/'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('DejaVu',normal='DejaVu',bold='DejaVu-Bold',italic='DejaVu',boldItalic='DejaVu-Bold')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyX',fontName='DejaVu',fontSize=9,leading=14,textColor=colors.HexColor('#344054'),spaceAfter=9))
styles.add(ParagraphStyle(name='TitleX',fontName='DejaVu-Bold',fontSize=27,leading=33,textColor=colors.HexColor('#202632'),spaceAfter=16))
styles.add(ParagraphStyle(name='H1X',fontName='DejaVu-Bold',fontSize=19,leading=25,textColor=colors.HexColor('#202632'),spaceAfter=14))
styles.add(ParagraphStyle(name='H2X',fontName='DejaVu-Bold',fontSize=11,leading=16,textColor=colors.HexColor('#fe424d'),spaceBefore=7,spaceAfter=7))
styles.add(ParagraphStyle(name='SmallX',fontName='DejaVu',fontSize=7.3,leading=10,textColor=colors.HexColor('#475467'),spaceAfter=6))
styles.add(ParagraphStyle(name='CellX',fontName='DejaVu',fontSize=7.5,leading=11,textColor=colors.HexColor('#344054')))
styles.add(ParagraphStyle(name='CodeX',fontName='DejaVu',fontSize=8,leading=12,backColor=colors.HexColor('#f2f4f7'),borderPadding=8,spaceAfter=12))
story=[]; md=[]
def txt(t,sty='BodyX'):
 story.append(Paragraph(t,styles[sty])); md.append(re.sub('<[^>]+>','',t))
def title(t): txt(t,'H1X'); md[-1]='# '+md[-1]
def sub(t): txt(t,'H2X'); md[-1]='## '+md[-1]
def page(): story.append(PageBreak()); md.append('\n---\n')
def table(rows,widths,header=True):
 data=[[Paragraph(escape(str(c)),styles['CellX']) for c in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1 if header else 0,hAlign='LEFT')
 cmds=[('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),1,colors.HexColor('#fe424d')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f8f9fb')])]
 if header: cmds.append(('BACKGROUND',(0,0),(-1,0),colors.HexColor('#fff0ef')))
 t.setStyle(TableStyle(cmds)); story.append(t); story.append(Spacer(1,10))
 md.extend([' | '.join(str(c) for c in row) for row in rows])
def image(name,maxw=480,maxh=340):
 path=p/'docs'/name; im=Image.open(path); ratio=min(maxw/im.width,maxh/im.height)
 story.append(RLImage(str(path),width=im.width*ratio,height=im.height*ratio)); story.append(Spacer(1,8)); md.append(f'![{name}]({name})')
def code(s): txt(escape(s).replace('\n','<br/>'),'CodeX')
# 1
story.append(Spacer(1,50)); txt('ADVANCED WEB PROGRAMMING','H2X'); txt('Wander Lust<br/>Assignment 2','TitleX')
txt('From frontend template to a PHP + MySQL web application','H1X')
txt('PHP · MySQL · HTML5 · CSS3 · JavaScript · Bootstrap 5 · Git · GitHub')
story.append(Spacer(1,20))
table([['Submission details','Complete before handing in'],['Team members / student IDs','________________________________________'],['Course section / instructor','________________________________________'],['Existing GitHub repository URL','________________________________________'],['Submission date / posted deadline','________________________________________']],[170,310])
sub('Delivery status')
txt('Working source code, schema, CLI sample-data importer, repeatable integration tests, screenshots, setup guide and this report are included. Verified locally: <b>30 of 30 integration checks passed</b>.')
txt('Unknown team details, repository URL and individual contributions are intentionally not invented. The student team must complete these fields and push the changes to the same Assignment 1 repository.','SmallX')
#2
page(); title('01 / Scope and continuity')
sub('What Assignment 1 contained')
txt('The supplied archive contained a single HTML page, a stylesheet and JavaScript. Its Wander Lust interface displayed ten static travel cards, a client-side add-listing form and a sign-in modal. New cards were inserted into the DOM only; there was no database or working authentication.')
sub('What was preserved and extended')
txt('The implementation retains the coral #fe424d accent, compass branding, Plus Jakarta Sans typography, Bootstrap card layout, original creator credit, and original ten listing titles, prices and image URLs. New illustrative locations and descriptions complete the database records. Original photos may not depict their stated locations.')
table([['Assignment requirement','Implemented evidence'],['Convert HTML to PHP','Public PHP routes; shared header, footer and card templates'],['Server-side processing and validation','POST handlers; field validation and error rendering'],['Dynamic PHP content','Database listing catalogue, detail page, search and dashboard'],['MySQL database','users and listings; keys, constraints and ownership relationship'],['Registration / login / logout','Hashed passwords, session rotation, POST logout'],['Protected and role-based pages','Member ownership checks and admin dashboard'],['Git repository + PDF report','Source package and report; team must push to the existing repo']],[165,315])
sub('Explicit scope boundary')
txt('This phase implements a travel-listing directory and secure classroom authentication flow. Reservations, payments, password recovery, email verification and image uploads are not part of this implementation.')
#3
page(); title('02 / Architecture and request flow')
table([['Directory','Responsibility'],['public/','Only document root: PHP routes and assets'],['app/','Bootstrap, PDO/auth/CSRF helpers and shared templates'],['config/','Example configuration; real config ignored by Git'],['database/','Table definitions and original sample listing data'],['scripts/','CLI-only transactional seed importer'],['tests/','Repeatable HTTP integration checks and recorded results'],['docs/','Screenshots, ER diagram, report source and verification logs']],[110,370])
sub('Read request')
code('Browser → public/index.php → app/bootstrap.php\n→ PDO query → escaped PHP template → HTML response')
sub('Write request')
code('POST form → session authentication → CSRF check\n→ ownership / role check → server validation\n→ prepared INSERT / UPDATE / DELETE → 303 redirect')
txt('Each request reloads the logged-in user and role from the database using the session user ID. This avoids treating a client-supplied role as authoritative. Public registration always inserts the member role.')
sub('Configuration and dependencies')
txt('No framework, package manager or build pipeline is required. PDO uses native prepared statements, UTF-8 and exception mode. Configuration lives outside the document root. Bootstrap 5.3.3 is bundled locally with its license; photos, optional fonts and icons use remote providers.')
#4
page(); title('03 / Database design')
image('ER-diagram.png',480,220)
txt('<b>Relationship:</b> one user may own zero or many listings; each listing has exactly one user. A foreign key prevents orphan listings. Owner deletion is restricted while listings exist; owner ID updates cascade.')
table([['Design decision','Reason'],['INT UNSIGNED auto-increment primary keys','Stable identity for users and listings'],['Unique email (case-insensitive collation)','Prevent duplicate registration and support login lookup'],['VARCHAR(255) password_hash','Store PHP-generated hashes, never plaintext passwords'],["ENUM('member','admin') role",'Fixed role vocabulary; member default'],['DECIMAL(8,2) price + CHECK > 0','Exact monetary display values and positive-price constraint'],['Owner index + foreign key','Efficient own-listing lookup and referential integrity'],['InnoDB, utf8mb4, timestamps','Relationships, Unicode data, creation/update metadata']],[195,285])
txt('The schema targets MySQL 8.0.16+ or MariaDB 10.4+. Runtime verification used MariaDB 11.8.6; Oracle MySQL was not available in this environment. Rerun the supplied tests on the instructor’s target server.','SmallX')
#5
page(); title('04 / Sample data and dynamic features')
sub('Repeatable sample-data import')
txt('The seed script reads ten records extracted from the supplied HTML. It creates one administrator and one member host; the host owns the ten sample listings. Both seed passwords must be supplied through environment variables and must differ. The importer hashes them at runtime, refuses non-empty tables and wraps inserts in a transaction.')
table([['Original listing','Nightly price (USD)'],*[[t,f'{v:,.2f}'] for t,v in zip(titles,prices)]],[350,130])
sub('Dynamic application behavior')
txt('Visitors can browse, search by title/city/country and open listing details. Members can create, update and delete only their own listings. Administrators can inspect user counts and manage any listing. Creation, updates and deletion persist across page refreshes and independent browser sessions.')
txt('The test run left one temporary member for audit, so screenshot/database evidence shows three users and ten listings. A fresh seed produces two users and ten listings. No test listing remains.','SmallX')
#6
page(); title('05 / Authentication and authorization')
table([['Operation','Implementation'],['Register','Validate name, email, password and confirmation; handle unique-email conflict; insert member only'],['Store password','password_hash(PASSWORD_DEFAULT); current tested runtime produced bcrypt hashes'],['Log in','Prepared email lookup; password_verify; optional hash upgrade with password_needs_rehash'],['Start authenticated session','Regenerate session ID, clear previous state and store user ID; issue fresh CSRF token'],['Session cookies','HttpOnly and SameSite=Lax; Secure on directly detected HTTPS'],['Protected routes','require_login redirects unauthenticated users to login'],['Ownership enforcement','Owner or admin required on edit and delete requests'],['Administrator access','require_admin checks database-loaded role'],['Log out','POST + CSRF; clear session data, expire cookie and destroy session']],[135,345])
sub('Password policy')
txt('Passwords must be 12–72 bytes. The 72-byte ceiling avoids silent truncation with bcrypt on the tested PHP runtime. Confirmation must match exactly. Password fields are never repopulated after validation errors. Registration rejects null bytes; the database contains only hashes.')
sub('Protection matrix')
table([['Action','Visitor','Member','Admin'],['Browse / search / detail','Yes','Yes','Yes'],['Create listing','No','Yes','Yes'],['Edit / delete own listing','No','Yes','Yes'],['Edit / delete others','No','No','Yes'],['User overview','No','No','Yes']],[210,90,90,90])
#7
page(); title('06 / Validation and defensive controls')
table([['Input / risk','Server behavior'],['Name / email','Byte-based name bounds; email format and length; lowercased email; database uniqueness'],['Title / description / place','Required values with explicit byte-based lower and upper bounds'],['Price','0.01–999999.99; no negative values or exponent notation; at most two decimals'],['Image URL','Valid HTTP(S) only; maximum 2048 bytes; no image upload or server-side fetching'],['Malformed or missing listing ID','Return HTTP 404 rather than exposing a query error'],['SQL injection','Parameters bound through native PDO prepared statements'],['Stored / reflected XSS','htmlspecialchars escapes text and attributes; description escaped before line breaks'],['CSRF','Random session-bound token checked on every mutation'],['Destructive GET / forged owner','Deletion requires POST and checks owner/admin independently of UI'],['Unexpected exception','Generic HTTP 500 response; internal details sent to server log']],[145,335])
sub('Known limits — not a production-ready security claim')
txt('The login throttle blocks the sixth failed attempt for five minutes within one session. A new cookie bypasses it; production needs centralized account/IP controls. Additional work includes tested idle/absolute session expiry, email verification/recovery, audit logging, a restrictive CSP, trusted reverse-proxy HTTPS handling, backups and pagination.')
txt('Remote image URLs are rendered by the browser, not fetched by PHP. Their availability and privacy behavior remain an external dependency. All price values are illustrative; the site accepts no payments.','SmallX')
#8
page(); title('07 / Interface evidence — catalogue')
image('01-catalogue.png',480,365)
txt('<b>Figure 1.</b> Actual desktop catalogue served by PHP against the seeded database. Original visual identity and listing-card structure are retained; search and displayed counts are server-driven.','SmallX')
sub('Registration and feedback')
txt('The former sign-in-only placeholder is replaced by working login and registration routes. Bootstrap form controls expose accessible labels and browser validation; the server independently validates direct HTTP submissions. Error summaries retain non-sensitive inputs, while successful writes use redirects and flash messages.')
image('02-register.png',330,205)
#9
page(); title('08 / Interface evidence — roles and mobile')
image('03-admin.png',480,330)
txt('<b>Figure 2.</b> Authenticated administrator dashboard, including user overview and listing management links. The extra test account is expected evidence of the integration run.','SmallX')
sub('Responsive behavior and visual verification')
txt('A local Chromium browser verified ten catalogue cards, successful administrator login and dashboard rendering. At 390 × 844, the collapsed navigation expanded correctly and displayed the authenticated links. Desktop screenshots were captured at 1440 × 1000. Additional detail and mobile screenshots are included in docs/.')
image('04-detail.png',360,205)
txt('<b>Figure 3.</b> Database detail page with owner/admin edit and delete actions.','SmallX')
#10
page(); title('09 / Verification results')
txt('<b>Environment:</b> PHP 8.4.27 with pdo_mysql; MariaDB 11.8.6; Python requests integration client; local Chromium for visual checks. All 16 PHP source files passed syntax linting. <b>30/30 HTTP integration checks passed.</b>')
results=json.loads((p/'tests/test-results.json').read_text())
table([['#','Automated check','Result']]+[[i+1,x['test'],'PASS' if x['passed'] else 'FAIL'] for i,x in enumerate(results)],[25,410,45])
txt('Evidence: tests/test-results.json, docs/php-lint.txt and docs/database-verification.txt. Tests use disposable data, leave one uniquely named test member, and remove their listing. No production deployment or independent penetration test is claimed.','SmallX')
#11
page(); title('10 / Setup, Git workflow and submission')
sub('Local installation summary')
txt('1. Copy this source into the existing Assignment 1 repository, retaining its .git history.<br/>2. Install/enable PHP 8.2+ with pdo_mysql and start MySQL/MariaDB.<br/>3. Create the wanderlust database and restricted application user.<br/>4. Import database/schema.sql using an administrative SQL account.<br/>5. Copy and edit config/config.example.php as config/config.php.<br/>6. Supply distinct seed passwords and run php scripts/seed.php.<br/>7. Start the local PHP server and test both roles. Full shell and PowerShell commands are in README.md.')
code('php -S 127.0.0.1:8000 -t public')
sub('Git collaboration and submission checklist')
txt('Use a backend feature branch, distribute meaningful tasks among all 2–5 members, review the changes and merge to the agreed submission branch. Commit the source, schema, seed importer, tests and report; never commit actual credentials. Verify the instructor can access the repository. Submit its existing URL and the completed PDF by the posted deadline.')
table([['Team member / ID','Actual contribution','Commit / PR evidence'],['__________________','____________________','__________________'],['__________________','____________________','__________________'],['__________________','____________________','__________________'],['__________________','____________________','__________________'],['__________________','____________________','__________________']],[155,170,155])
sub('Primary documentation for further review')
txt('PHP manual: password_hash, password_verify, PDO::prepare, session_regenerate_id and htmlspecialchars — www.php.net/manual/en/.<br/>MySQL Reference Manual: CREATE TABLE and foreign key constraints — dev.mysql.com/doc/refman/8.0/en/create-table.html.<br/>Bootstrap 5.3 documentation — getbootstrap.com/docs/5.3/.','SmallX')
txt('No GitHub URL, student identity, submission deadline or personal contribution has been fabricated. Complete those details before submission. This generated implementation should be reviewed and understood by every team member, in line with the course’s permitted-assistance rules.','SmallX')
# PDF rendering
report=p/'WanderLust_Assignment2_Report.pdf'
def decoration(canvas,doc):
 w,h=doc.pagesize
 canvas.setFillColor(colors.HexColor('#fe424d'));canvas.rect(0,h-8,w,8,fill=1,stroke=0)
 canvas.setFont('DejaVu',8);canvas.setFillColor(colors.HexColor('#667085'))
 if doc.page>1:
  canvas.drawString(48,h-33,'WANDER LUST  /  ASSIGNMENT 2')
 canvas.setStrokeColor(colors.HexColor('#e4e7ec'));canvas.line(48,40,w-48,40)
 canvas.drawString(48,26,'Advanced Web Programming · PHP / MySQL')
 canvas.drawRightString(w-48,26,str(doc.page))
doc=SimpleDocTemplate(str(report),pagesize=(595.28,841.89),rightMargin=48,leftMargin=48,topMargin=56,bottomMargin=54,title='Wander Lust — Assignment 2 Report',author='Student team — complete before submission')
doc.build(story,onFirstPage=decoration,onLaterPages=decoration)
(p/'docs/report-source.md').write_text('\n\n'.join(md))
import shutil
shutil.copyfile(report,p/'docs'/report.name)
print('Report saved:',report)
