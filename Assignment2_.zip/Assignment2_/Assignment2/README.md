# Wander Lust — Assignment 2

PHP / MySQL continuation of the supplied Assignment 1 Wander Lust frontend.
The original coral palette, brand, travel-card layout, ten listing titles, image
URLs and prices are retained. Locations/descriptions were added as illustrative
sample data, not verified property details. This is an academic listing directory,
not a booking or payment service.

## Requirements
- PHP 8.2+ with PDO and pdo_mysql; sessions enabled.
- MySQL 8.0.16+ or MariaDB 10.4+ (InnoDB).
- A modern browser. No Composer, npm or build step required.
- Internet for remote Unsplash images, Google Fonts and Font Awesome icons.
  Bootstrap 5.3.3 CSS/JS is bundled locally and retains its MIT license.

## 1. Keep the SAME GitHub repository
Back up Assignment 1, then copy this package's contents into the root of your
existing local clone. Preserve the existing .git folder and commit history.
Do not create a replacement repository. The public web root must be public/.

## 2. Create a database
Run these commands in your MySQL administrative client; replace the sample
placeholder with a strong database password. Do not include real secrets in Git.

```sql
CREATE DATABASE wanderlust CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'wanderlust_app'@'127.0.0.1' IDENTIFIED BY 'CHOOSE_A_STRONG_DB_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON wanderlust.* TO 'wanderlust_app'@'127.0.0.1';
```

Import the schema as an administrative user (it creates tables, not the database):
```bash
mysql -u root -p wanderlust < database/schema.sql
```
On Windows, use the SQL client's `SOURCE` command or select `wanderlust` and
import `database/schema.sql` in phpMyAdmin. This schema is for a fresh database;
do not re-import it into an existing populated database.

## 3. Configure PHP
Copy `config/config.example.php` to `config/config.php`, then set host, port,
database name, username and password. The real config file is ignored by Git.
DB_HOST, DB_PORT, DB_NAME, DB_USER and DB_PASS environment variables override it.
Check the PHP installation with `php -v` and `php -m`; pdo_mysql must be enabled.

## 4. Insert sample data
The CLI-only seed script inserts two users and the ten original listing cards.
It refuses to run unless both tables are empty and uses a transaction. Passwords
are hashed at seed time; no shared preset password is shipped.
Choose different 12–72 byte passwords and save them securely.

macOS / Linux / Git Bash:
```bash
SEED_ADMIN_PASSWORD='YOUR_UNIQUE_ADMIN_PASSPHRASE' \
SEED_HOST_PASSWORD='YOUR_UNIQUE_HOST_PASSPHRASE' php scripts/seed.php
```
Windows PowerShell:
```powershell
$env:SEED_ADMIN_PASSWORD='YOUR_UNIQUE_ADMIN_PASSPHRASE'
$env:SEED_HOST_PASSWORD='YOUR_UNIQUE_HOST_PASSPHRASE'
php scripts/seed.php
Remove-Item Env:SEED_ADMIN_PASSWORD, Env:SEED_HOST_PASSWORD
```
Accounts:
- `admin@wanderlust.test`: administrator; password chosen above.
- `host@wanderlust.test`: member; owns the ten samples; password chosen above.
- New registrations are always members, regardless of submitted role fields.

## 5. Run locally
From the project root:
```bash
php -S 127.0.0.1:8000 -t public
```
Open http://127.0.0.1:8000/index.php. Keep the terminal open. The PHP development
server is only for local use. For Apache/XAMPP, configure a virtual host whose
DocumentRoot is this project's public directory, not the project root. If using
XAMPP PHP, run its PHP executable and ensure its pdo_mysql extension is enabled.

## Features and authorization
| Visitor | Read/search listings; register; log in |
|---|---|
| Member | Visitor features + own listing create/read/update/delete; logout |
| Admin | Member features + user overview and edit/delete of any listing |

Authentication uses password_hash/password_verify, fresh session IDs on login,
HttpOnly and SameSite=Lax cookies, and Secure cookies when directly using HTTPS.
Sessions store a user ID; role is reloaded from the database on each request.
All mutations require a POST form and CSRF token, including logout. Prepared
statements handle user input; htmlspecialchars escapes rendered text/attributes.
The server rejects malformed forms, invalid IDs, invalid prices and unsafe image
URL schemes. Database constraints enforce unique emails, valid owners and
positive prices. Names/fields use documented byte-based bounds in validation.

## Structure
```
app/             shared bootstrap, database/auth helpers, header/footer/cards
config/          configuration example (real config ignored)
database/        schema.sql and ten sample listing records in listings.json
public/          PHP routes and static assets; ONLY document root
scripts/         CLI-only sample data importer
tests/          repeatable integration checks and recorded results
docs/           report source, screenshots, ER diagram, verification notes
```

Routes: index.php, register.php, login.php, logout.php, my-listings.php,
listing.php?id=N, listing-form.php (create), listing-form.php?id=N (edit),
delete-listing.php (POST), admin.php. Shared code and configuration stay outside
public/. Edit authorization is checked on every request, not just button display.

## Database design
users (1) ----< listings (many), via listings.user_id -> users.id.
Role is a two-value ENUM. Each listing has exactly one owner; a user may own no
listings. ON DELETE RESTRICT prevents orphan records, ON UPDATE CASCADE preserves
referential integrity. DECIMAL(8,2) stores display prices; timestamps record
creation and updates. Unique email and owner index support common lookups.

## Test and demonstrate
1. Read/search the public catalogue; invalid listing ID should return 404.
2. Register a member; test invalid email, weak password and duplicate email.
3. Log in, add a listing, refresh and verify persistence.
4. Edit/delete your listing. Another member must receive 403 for those operations.
5. Log in as admin; inspect users and manage another owner's listing.
6. Log out; verify protected pages redirect to login.
7. Open on mobile and expand the navigation menu.

Syntax checks (macOS/Linux/Git Bash):
```bash
find . -name '*.php' -print0 | xargs -0 -n1 php -l
```
Optional integration tests use Python 3 + requests and a DISPOSABLE seeded DB:
```bash
python -m pip install requests
BASE_URL=http://127.0.0.1:8000 \
TEST_ADMIN_PASSWORD='YOUR_UNIQUE_ADMIN_PASSPHRASE' \
TEST_HOST_PASSWORD='YOUR_UNIQUE_HOST_PASSPHRASE' pythontests/smoke_test.py
```
The tests create one uniquely named member account per run and remove their
listing. Do not run against production. They expect the original ten seeded
listings and their titles. Results overwritetests/test-results.json. The
included results record 30/30 passing checks on PHP 8.4.27 / MariaDB 11.8.6.
Oracle MySQL was not available for runtime testing; rerun tests on your setup.

## Git/GitHub submission
Use the existing repository and branch workflow agreed by your team:
```bash
git status
git switch -c assignment-2-backend
git add .gitignore app config/config.example.php database public scripts tests docs README.md
git commit -m "Implement PHP MySQL listings and session authentication"
git push -u origin assignment-2-backend
```
Review the diff, open a pull request, and merge to your agreed submission branch.
Check that config/config.php and real credentials are NOT tracked. Add the PDF
report todocs/ if your instructor expects it in Git, then commit it separately.
Do not fabricate commit history: all 2–5 team members should make meaningful
contributions. Confirm the instructor can access a private repository, if used.

Before submitting, fill in team member names/IDs, course section, repository URL,
and actual contribution table indocs/report-source.md and regenerate/edit the
report. The supplied PDF intentionally leaves unknown submission details blank.
Submit the SAME repository link and completed PDF by the posted deadline.
No GitHub repository has been created, pushed, or linked automatically.

## Limitations / deployment notes
- This is a classroom implementation, not a production security certification.
- A five-attempt/five-minute throttle is session-based and can be bypassed with
  new cookies. Production needs centralized account/IP rate limits and monitoring.
- No email verification, password reset, booking, payment, file upload or user
  deletion/role-change UI is implemented; those are outside this assignment.
- Catalogue queries are not paginated; add pagination before large datasets.
- Use HTTPS and secure environment-managed credentials in production. With a
  reverse proxy, configure HTTPS detection using a trusted proxy policy.
- Add a tested idle/absolute session timeout, audit logs, security headers/CSP,
  dependency maintenance, and a backup/recovery strategy before real deployment.
- Remote photos/icons/fonts may be unavailable offline; Bootstrap is local.
- Original photos are retained as supplied and may not depict the stated places.
- The original creator credit “Made by Usman.J” is retained; the final report's
  team contribution fields must reflect the real team, not invented names.

## Troubleshooting
- Connection error: start MySQL/MariaDB; check config, TCP port and user grants.
- `could not find driver`: enable pdo_mysql in the active PHP configuration.
- Blank server response: inspect the PHP error log or development-server terminal.
- Seed refused: use a new empty database; do not erase real work to rerun a demo.
- Invalid CSRF token: reload the form; enable cookies; log in again if needed.
- Styles missing: keep public/assets intact and start with `-t public`.

## Primary implementation references
PHP manual: password_hash, password_verify, PDO::prepare,
session_regenerate_id, htmlspecialchars (https://www.php.net/manual/en/).
MySQL reference manual: CREATE TABLE and FOREIGN KEY constraints
(https://dev.mysql.com/doc/refman/8.0/en/create-table.html).
Bootstrap 5.3 documentation (https://getbootstrap.com/docs/5.3/).
These are reference reading, not claims of independent security review.
