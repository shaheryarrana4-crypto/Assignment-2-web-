ADVANCED WEB PROGRAMMING

Wander LustAssignment 2

From frontend template to a PHP + MySQL web application

PHP · MySQL · HTML5 · CSS3 · JavaScript · Bootstrap 5 · Git · GitHub

Submission details | Complete before handing in

Team members / student IDs | ________________________________________

Course section / instructor | ________________________________________

Existing GitHub repository URL | ________________________________________

Submission date / posted deadline | ________________________________________

## Delivery status

Working source code, schema, CLI sample-data importer, repeatable integration tests, screenshots, setup guide and this report are included. Verified locally: 30 of 30 integration checks passed.

Unknown team details, repository URL and individual contributions are intentionally not invented. The student team must complete these fields and push the changes to the same Assignment 1 repository.


---


# 01 / Scope and continuity

## What Assignment 1 contained

The supplied archive contained a single HTML page, a stylesheet and JavaScript. Its Wander Lust interface displayed ten static travel cards, a client-side add-listing form and a sign-in modal. New cards were inserted into the DOM only; there was no database or working authentication.

## What was preserved and extended

The implementation retains the coral #fe424d accent, compass branding, Plus Jakarta Sans typography, Bootstrap card layout, original creator credit, and original ten listing titles, prices and image URLs. New illustrative locations and descriptions complete the database records. Original photos may not depict their stated locations.

Assignment requirement | Implemented evidence

Convert HTML to PHP | Public PHP routes; shared header, footer and card templates

Server-side processing and validation | POST handlers; field validation and error rendering

Dynamic PHP content | Database listing catalogue, detail page, search and dashboard

MySQL database | users and listings; keys, constraints and ownership relationship

Registration / login / logout | Hashed passwords, session rotation, POST logout

Protected and role-based pages | Member ownership checks and admin dashboard

Git repository + PDF report | Source package and report; team must push to the existing repo

## Explicit scope boundary

This phase implements a travel-listing directory and secure classroom authentication flow. Reservations, payments, password recovery, email verification and image uploads are not part of this implementation.


---


# 02 / Architecture and request flow

Directory | Responsibility

public/ | Only document root: PHP routes and assets

app/ | Bootstrap, PDO/auth/CSRF helpers and shared templates

config/ | Example configuration; real config ignored by Git

database/ | Table definitions and original sample listing data

scripts/ | CLI-only transactional seed importer

tests/ | Repeatable HTTP integration checks and recorded results

docs/ | Screenshots, ER diagram, report source and verification logs

## Read request

Browser → public/index.php → app/bootstrap.php→ PDO query → escaped PHP template → HTML response

## Write request

POST form → session authentication → CSRF check→ ownership / role check → server validation→ prepared INSERT / UPDATE / DELETE → 303 redirect

Each request reloads the logged-in user and role from the database using the session user ID. This avoids treating a client-supplied role as authoritative. Public registration always inserts the member role.

## Configuration and dependencies

No framework, package manager or build pipeline is required. PDO uses native prepared statements, UTF-8 and exception mode. Configuration lives outside the document root. Bootstrap 5.3.3 is bundled locally with its license; photos, optional fonts and icons use remote providers.


---


# 03 / Database design

![ER-diagram.png](ER-diagram.png)

Relationship: one user may own zero or many listings; each listing has exactly one user. A foreign key prevents orphan listings. Owner deletion is restricted while listings exist; owner ID updates cascade.

Design decision | Reason

INT UNSIGNED auto-increment primary keys | Stable identity for users and listings

Unique email (case-insensitive collation) | Prevent duplicate registration and support login lookup

VARCHAR(255) password_hash | Store PHP-generated hashes, never plaintext passwords

ENUM('member','admin') role | Fixed role vocabulary; member default

DECIMAL(8,2) price + CHECK > 0 | Exact monetary display values and positive-price constraint

Owner index + foreign key | Efficient own-listing lookup and referential integrity

InnoDB, utf8mb4, timestamps | Relationships, Unicode data, creation/update metadata

The schema targets MySQL 8.0.16+ or MariaDB 10.4+. Runtime verification used MariaDB 11.8.6; Oracle MySQL was not available in this environment. Rerun the supplied tests on the instructor’s target server.


---


# 04 / Sample data and dynamic features

## Repeatable sample-data import

The seed script reads ten records extracted from the supplied HTML. It creates one administrator and one member host; the host owns the ten sample listings. Both seed passwords must be supplied through environment variables and must differ. The importer hashes them at runtime, refuses non-empty tables and wraps inserts in a transaction.

Original listing | Nightly price (USD)

Modern Loft in Downtown | 1,200.00

Mountain Retreat | 1,000.00

Historic Villa in Tuscany | 2,500.00

Secluded Treehouse Getaway | 800.00

Beachfront Paradise | 2,000.00

Rustic Cabin by the Lake | 900.00

Luxury Penthouse with City Views | 3,500.00

Ski-In/Ski-Out Chalet | 3,000.00

Safari Lodge in the Serengeti | 4,000.00

Historic Canal House | 1,800.00

## Dynamic application behavior

Visitors can browse, search by title/city/country and open listing details. Members can create, update and delete only their own listings. Administrators can inspect user counts and manage any listing. Creation, updates and deletion persist across page refreshes and independent browser sessions.

The test run left one temporary member for audit, so screenshot/database evidence shows three users and ten listings. A fresh seed produces two users and ten listings. No test listing remains.


---


# 05 / Authentication and authorization

Operation | Implementation

Register | Validate name, email, password and confirmation; handle unique-email conflict; insert member only

Store password | password_hash(PASSWORD_DEFAULT); current tested runtime produced bcrypt hashes

Log in | Prepared email lookup; password_verify; optional hash upgrade with password_needs_rehash

Start authenticated session | Regenerate session ID, clear previous state and store user ID; issue fresh CSRF token

Session cookies | HttpOnly and SameSite=Lax; Secure on directly detected HTTPS

Protected routes | require_login redirects unauthenticated users to login

Ownership enforcement | Owner or admin required on edit and delete requests

Administrator access | require_admin checks database-loaded role

Log out | POST + CSRF; clear session data, expire cookie and destroy session

## Password policy

Passwords must be 12–72 bytes. The 72-byte ceiling avoids silent truncation with bcrypt on the tested PHP runtime. Confirmation must match exactly. Password fields are never repopulated after validation errors. Registration rejects null bytes; the database contains only hashes.

## Protection matrix

Action | Visitor | Member | Admin

Browse / search / detail | Yes | Yes | Yes

Create listing | No | Yes | Yes

Edit / delete own listing | No | Yes | Yes

Edit / delete others | No | No | Yes

User overview | No | No | Yes


---


# 06 / Validation and defensive controls

Input / risk | Server behavior

Name / email | Byte-based name bounds; email format and length; lowercased email; database uniqueness

Title / description / place | Required values with explicit byte-based lower and upper bounds

Price | 0.01–999999.99; no negative values or exponent notation; at most two decimals

Image URL | Valid HTTP(S) only; maximum 2048 bytes; no image upload or server-side fetching

Malformed or missing listing ID | Return HTTP 404 rather than exposing a query error

SQL injection | Parameters bound through native PDO prepared statements

Stored / reflected XSS | htmlspecialchars escapes text and attributes; description escaped before line breaks

CSRF | Random session-bound token checked on every mutation

Destructive GET / forged owner | Deletion requires POST and checks owner/admin independently of UI

Unexpected exception | Generic HTTP 500 response; internal details sent to server log

## Known limits — not a production-ready security claim

The login throttle blocks the sixth failed attempt for five minutes within one session. A new cookie bypasses it; production needs centralized account/IP controls. Additional work includes tested idle/absolute session expiry, email verification/recovery, audit logging, a restrictive CSP, trusted reverse-proxy HTTPS handling, backups and pagination.

Remote image URLs are rendered by the browser, not fetched by PHP. Their availability and privacy behavior remain an external dependency. All price values are illustrative; the site accepts no payments.


---


# 07 / Interface evidence — catalogue

![01-catalogue.png](01-catalogue.png)

Figure 1. Actual desktop catalogue served by PHP against the seeded database. Original visual identity and listing-card structure are retained; search and displayed counts are server-driven.

## Registration and feedback

The former sign-in-only placeholder is replaced by working login and registration routes. Bootstrap form controls expose accessible labels and browser validation; the server independently validates direct HTTP submissions. Error summaries retain non-sensitive inputs, while successful writes use redirects and flash messages.

![02-register.png](02-register.png)


---


# 08 / Interface evidence — roles and mobile

![03-admin.png](03-admin.png)

Figure 2. Authenticated administrator dashboard, including user overview and listing management links. The extra test account is expected evidence of the integration run.

## Responsive behavior and visual verification

A local Chromium browser verified ten catalogue cards, successful administrator login and dashboard rendering. At 390 × 844, the collapsed navigation expanded correctly and displayed the authenticated links. Desktop screenshots were captured at 1440 × 1000. Additional detail and mobile screenshots are included in docs/.

![04-detail.png](04-detail.png)

Figure 3. Database detail page with owner/admin edit and delete actions.


---


# 09 / Verification results

Environment: PHP 8.4.27 with pdo_mysql; MariaDB 11.8.6; Python requests integration client; local Chromium for visual checks. All 16 PHP source files passed syntax linting. 30/30 HTTP integration checks passed.

# | Automated check | Result

1 | Public database-backed catalogue | PASS

2 | Search filters listings | PASS

3 | SQL injection search is treated as data | PASS

4 | Unauthenticated create redirects to login | PASS

5 | Malformed ID returns 404 | PASS

6 | Registration rejects missing CSRF | PASS

7 | Valid registration | PASS

8 | Duplicate email rejected | PASS

9 | Server-side registration validation | PASS

10 | Bad password rejected | PASS

11 | Login creates authenticated session | PASS

12 | Login rotates session identifier | PASS

13 | Session cookie uses HttpOnly and SameSite | PASS

14 | Registration cannot elevate role | PASS

15 | Negative price and unsafe image scheme rejected | PASS

16 | Create persists and redirects | PASS

17 | Stored XSS output is escaped | PASS

18 | Persistence visible from another session | PASS

19 | Another member cannot edit | PASS

20 | Another member cannot delete | PASS

21 | Owner can update listing | PASS

22 | GET cannot delete | PASS

23 | Delete requires CSRF | PASS

24 | Admin dashboard permitted | PASS

25 | Admin can edit another owner listing | PASS

26 | Admin can delete another owner listing | PASS

27 | Deleted record returns 404 | PASS

28 | Logout redirects to login | PASS

29 | Logout revokes protected access | PASS

30 | Session throttle blocks sixth failed login | PASS

Evidence: tests/test-results.json, docs/php-lint.txt and docs/database-verification.txt. Tests use disposable data, leave one uniquely named test member, and remove their listing. No production deployment or independent penetration test is claimed.


---


# 10 / Setup, Git workflow and submission

## Local installation summary

1. Copy this source into the existing Assignment 1 repository, retaining its .git history.2. Install/enable PHP 8.2+ with pdo_mysql and start MySQL/MariaDB.3. Create the wanderlust database and restricted application user.4. Import database/schema.sql using an administrative SQL account.5. Copy and edit config/config.example.php as config/config.php.6. Supply distinct seed passwords and run php scripts/seed.php.7. Start the local PHP server and test both roles. Full shell and PowerShell commands are in README.md.

php -S 127.0.0.1:8000 -t public

## Git collaboration and submission checklist

Use a backend feature branch, distribute meaningful tasks among all 2–5 members, review the changes and merge to the agreed submission branch. Commit the source, schema, seed importer, tests and report; never commit actual credentials. Verify the instructor can access the repository. Submit its existing URL and the completed PDF by the posted deadline.

Team member / ID | Actual contribution | Commit / PR evidence

__________________ | ____________________ | __________________

__________________ | ____________________ | __________________

__________________ | ____________________ | __________________

__________________ | ____________________ | __________________

__________________ | ____________________ | __________________

## Primary documentation for further review

PHP manual: password_hash, password_verify, PDO::prepare, session_regenerate_id and htmlspecialchars — www.php.net/manual/en/.MySQL Reference Manual: CREATE TABLE and foreign key constraints — dev.mysql.com/doc/refman/8.0/en/create-table.html.Bootstrap 5.3 documentation — getbootstrap.com/docs/5.3/.

No GitHub URL, student identity, submission deadline or personal contribution has been fabricated. Complete those details before submission. This generated implementation should be reviewed and understood by every team member, in line with the course’s permitted-assistance rules.