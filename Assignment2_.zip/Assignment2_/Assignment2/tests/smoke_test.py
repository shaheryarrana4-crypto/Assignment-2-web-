"""Integration tests for a disposable seeded database. Requires requests.
Run with BASE_URL, TEST_ADMIN_PASSWORD and TEST_HOST_PASSWORD environment variables.
Deletes its temporary listing; leaves one uniquely named test member for audit.
"""
import os, re, time, json
from pathlib import Path
import requests
BASE=os.getenv('BASE_URL','http://127.0.0.1:8085').rstrip('/')+'/'
results=[]
def check(name, condition):
    results.append({'test':name,'passed':bool(condition)})
    if not condition: raise AssertionError(name)
def token(response):
    return re.search(r'name="csrf" value="([a-f0-9]+)"',response.text).group(1)
def get(s,path): return s.get(BASE+path,timeout=20)
def submit(s,path,data,refer=None,redirect=True):
    page=get(s,refer or path)
    return s.post(BASE+path,data={'csrf':token(page),**data},allow_redirects=redirect,timeout=20)
def login(s,email,password): return submit(s,'login.php',{'email':email,'password':password})
try:
    guest=requests.Session()
    r=get(guest,'index.php'); check('Public database-backed catalogue',r.status_code==200 and 'Historic Canal House' in r.text)
    check('Search filters listings','Historic Canal House' not in get(guest,'index.php?q=Tuscany').text)
    check('SQL injection search is treated as data','No listings found.' in get(guest,"index.php?q=%27%20OR%201%3D1--").text)
    check('Unauthenticated create redirects to login',get(guest,'listing-form.php').url.endswith('login.php'))
    check('Malformed ID returns 404',get(guest,'listing.php?id[]=1').status_code==404)
    r=guest.post(BASE+'register.php',data={'name':'Guest'},timeout=20)
    check('Registration rejects missing CSRF',r.status_code==403)
    email='test-'+str(time.time_ns())+'@example.test'; password='IntegrationTest-2026!'
    r=submit(guest,'register.php',{'name':'Test Member','email':email,'password':password,'confirm':password,'role':'admin'})
    check('Valid registration', 'Registration successful' in r.text)
    r=submit(guest,'register.php',{'name':'Test Member','email':email,'password':password,'confirm':password})
    check('Duplicate email rejected','already registered' in r.text)
    r=submit(guest,'register.php',{'name':'X','email':'bad','password':'short','confirm':'other'})
    check('Server-side registration validation','Enter a valid email' in r.text and 'Passwords do not match' in r.text)
    r=login(guest,email,'wrong'); check('Bad password rejected','Invalid email or password' in r.text)
    old=guest.cookies.get('PHPSESSID')
    r=login(guest,email,password); check('Login creates authenticated session','My Listings' in r.text and r.url.endswith('my-listings.php'))
    check('Login rotates session identifier',guest.cookies.get('PHPSESSID')!=old)
    check('Session cookie uses HttpOnly and SameSite',any('HttpOnly' in h.headers.get('Set-Cookie','') and 'SameSite=Lax' in h.headers.get('Set-Cookie','') for h in r.history))
    check('Registration cannot elevate role',get(guest,'admin.php').status_code==403)
    payload={'title':'<script>alert(1)</script>','image_url':'https://images.unsplash.com/photo-1501785888041-af3ef285b470','price':'123.45','location':'Test City','country':'Test Country','description':'Integration test listing description.'}
    r=submit(guest,'listing-form.php',{**payload,'price':'-1','image_url':'javascript:alert(1)'})
    check('Negative price and unsafe image scheme rejected','Price must be' in r.text and 'Image must be' in r.text)
    r=submit(guest,'listing-form.php',payload); check('Create persists and redirects',r.status_code==200 and 'Listing created.' in r.text)
    listing_id=re.search(r'id=(\d+)',r.url).group(1)
    check('Stored XSS output is escaped','&lt;script&gt;alert(1)&lt;/script&gt;' in r.text and '<script>alert(1)</script>' not in r.text)
    check('Persistence visible from another session','&lt;script&gt;' in get(requests.Session(),'listing.php?id='+listing_id).text)
    host=requests.Session(); login(host,'host@wanderlust.test',os.environ['TEST_HOST_PASSWORD'])
    check('Another member cannot edit',get(host,'listing-form.php?id='+listing_id).status_code==403)
    r=submit(host,'delete-listing.php',{'id':listing_id},refer='my-listings.php'); check('Another member cannot delete',r.status_code==403)
    r=submit(guest,'listing-form.php?id='+listing_id,{**payload,'title':'Updated integration listing'})
    check('Owner can update listing','Updated integration listing' in r.text and 'Listing updated.' in r.text)
    check('GET cannot delete',get(guest,'delete-listing.php').status_code==405)
    r=guest.post(BASE+'delete-listing.php',data={'id':listing_id},timeout=20); check('Delete requires CSRF',r.status_code==403)
    admin=requests.Session(); login(admin,'admin@wanderlust.test',os.environ['TEST_ADMIN_PASSWORD'])
    check('Admin dashboard permitted',get(admin,'admin.php').status_code==200 and 'User overview' in get(admin,'admin.php').text)
    check('Admin can edit another owner listing',get(admin,'listing-form.php?id='+listing_id).status_code==200)
    r=submit(admin,'delete-listing.php',{'id':listing_id},refer='admin.php'); check('Admin can delete another owner listing','Listing deleted.' in r.text)
    check('Deleted record returns 404',get(guest,'listing.php?id='+listing_id).status_code==404)
    r=submit(guest,'logout.php',{},refer='my-listings.php'); check('Logout redirects to login',r.url.endswith('login.php'))
    check('Logout revokes protected access',get(guest,'my-listings.php').url.endswith('login.php'))
    limited=requests.Session()
    for i in range(6): r=login(limited,'nobody@example.test','not-the-password')
    check('Session throttle blocks sixth failed login',r.status_code==429)
finally:
    out=Path(__file__).parent/'test-results.json'
    out.write_text(json.dumps(results,indent=2))
    for item in results: print(('PASS' if item['passed'] else 'FAIL')+' '+item['test'])
    print(f'{sum(x["passed"] for x in results)}/{len(results)} checks passed')
