<?php
require __DIR__ . '/../app/bootstrap.php';
if (!post()) { header('Allow: POST'); fail(405, 'Log out using the navigation button.'); }
csrf_check(); $_SESSION=[];
$params=session_get_cookie_params();
setcookie(session_name(), '', ['expires'=>time()-42000,'path'=>$params['path'],'domain'=>$params['domain'],'secure'=>$params['secure'],'httponly'=>true,'samesite'=>'Lax']);
session_destroy(); go('login.php');
